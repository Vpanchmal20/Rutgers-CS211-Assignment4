#ifndef _first_h
#define _first_h
struct cacheStructure** cache;

unsigned long int count;
typedef struct cacheStructure{
	unsigned long int tag, Recently_Used;
	int valid;
}cacheStructure;

void _readFromInput(unsigned long int np_tagIndex,unsigned long int np_setIndex,int assoc);
cacheStructure** createcache(int numSet,int assoc);
void _writeToCache(unsigned long int np_tagIndex,unsigned long int np_setIndex,int assoc);
void empty(int numSet, int assoc);
bool isPowerOfTwo(int value);
void p_prefetch(unsigned long int np_tagIndex,unsigned long int np_setIndex,int assoc);
void np_prefetchRead(unsigned long int np_tagIndex,unsigned long int np_setIndex,int assoc,unsigned long int p_tagIndex,unsigned long int p_setIndex, int input);
void np_prefetchWrite(unsigned long int np_tagIndex,unsigned long int np_setIndex,int assoc,unsigned long int p_tagIndex,unsigned long int p_setIndex, int input);
void struct1(unsigned long int np_tagIndex,unsigned long int np_setIndex, int i, int check);
void struct2(unsigned long int np_tagIndex,unsigned long int np_setIndex,int assoc, int check1);
void struct3(int check2, int input, int i, unsigned long int np_setIndex);
void print(int options);
#endif
